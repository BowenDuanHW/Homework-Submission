const PI = 3.14;

// Simple implementation of the formulas
function areaOfSquare(length) {
    return length * length;
}

function areaOfTriangle(base, height) {
    return base * height * 0.5;
}


function areaOfTrapazoid(a, b, height) {
    return (a + b) * height * 0.5;
}


function areaOfCircle(radius) {
    return PI * radius ** 2;
}

function areaOfParallelogram(base, height) {
    return base * height;
}

function areaOfRightCylinder(radius, height) {
    return 2 * PI * radius * height + 2 * PI * radius ** 2;
}

// This function is to verify if the value of the area entered by users is correct
function verifyAnswer(shape, areaCalculator, inputElementIds, areaElementId) {
    let correctAreaSection = document.getElementById("correct_answer_sec");
    let incorrectAreaSection = document.getElementById("wrong_answer_sec");

    correctAreaSection.style.display = "none";
    incorrectAreaSection.style.display = "none";

    let inputData = inputElementIds.map(elementId => Number(document.getElementById(elementId).value));
    let isInputInvalid = inputData.some(input => Number.isNaN(input) || input <= 0);

    if (isInputInvalid) {
        window.alert("Invalid Input! You cannot enter negative numbers or empty numbers");
    } else {
        let userArea = Number(document.getElementById(areaElementId).value).toFixed(2);
        let calculatedArea = areaCalculator(...inputData).toFixed(2);

        if (userArea === calculatedArea) {
            correctAreaSection.style.display = "block";
        } else {
            incorrectAreaSection.style.display = "block";
            document.getElementById("wrong_answer_message").textContent = `The correct answer should be ${calculatedArea}`;
        }
    }
}

// This function resets the values of the input parameters to null
function reset() {
    // Square
    document.getElementById("Square_side").value = "";
    document.getElementById("Square_area").value = "";
    document.getElementById("square_sec").style.display = "none";

    // Triangle
    document.getElementById("Triangle_base").value = "";
    document.getElementById("Triangle_height").value = "";
    document.getElementById("Triangle_area").value = "";
    document.getElementById("triangle_sec").style.display = "none";

    // Trapazoid
    document.getElementById("trapazoid_base_1").value = "";
    document.getElementById("trapazoid_base_2").value = "";
    document.getElementById("trapazoid_height").value = "";
    document.getElementById("trapazoid_area").value = "";
    document.getElementById("trapazoid_sec").style.display = "none";

    // Circle
    document.getElementById("Circle_radius").value = "";
    document.getElementById("Circle_area").value = "";
    document.getElementById("circle_sec").style.display = "none";

    // Parallelogram
    document.getElementById("Parallelogram_base").value = "";
    document.getElementById("Parallelogram_height").value = "";
    document.getElementById("Parallelogram_area").value = "";
    document.getElementById("parallelogram_sec").style.display = "none";

    // Right Cylinder
    document.getElementById("Cylinder_radius").value = "";
    document.getElementById("Cylinder_height").value = "";
    document.getElementById("Cylinder_area").value = "";
    document.getElementById("rightCylinder_sec").style.display = "none";

    document.getElementById("correct_answer_sec").style.display = "none";
    document.getElementById("wrong_answer_sec").style.display = "none";
    document.getElementById("main").style.display = "block";
    document.getElementById("chooser").selectedIndex = "0";
}

// export all the functions 
export {
    areaOfSquare,
    areaOfTriangle,
    areaOfTrapazoid,
    areaOfCircle,
    areaOfParallelogram,
    areaOfRightCylinder,
    verifyAnswer,
    reset
};